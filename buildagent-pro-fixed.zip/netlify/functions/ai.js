exports.handler = async function(event, context) {
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, body: "Method Not Allowed" };
  }

  const API_KEY = process.env.ANTHROPIC_API_KEY;
  if (!API_KEY) {
    return {
      statusCode: 500,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ error: "API key not configured" })
    };
  }
  
  try {
    const body = JSON.parse(event.body);
    const { type, prompt, systemPrompt } = body;

    let sysPrompt = systemPrompt || "You are a helpful AI assistant.";
    
    if (type === "buildAgent") {
      sysPrompt = `You are an expert AI Agent Builder. Return ONLY valid JSON (no markdown, no code blocks):
{"agentName":"Name","tagline":"tagline","role":"role","personality":"personality","systemPrompt":"150 word system prompt","capabilities":["c1","c2","c3","c4","c5"],"tools":["t1","t2","t3"],"exampleTasks":["task1","task2","task3"],"bestFor":"audience","tone":"professional","avatar":"emoji"}`;
    } else if (type === "content") {
      sysPrompt = "You are a professional content creator. Create high-quality, engaging content as requested. Be creative and thorough.";
    } else if (type === "translate") {
      sysPrompt = `You are a professional translator. Translate the following text to ${systemPrompt}. Only return the translated text, nothing else.`;
    } else if (type === "chat") {
      sysPrompt = systemPrompt || "You are a helpful AI assistant.";
    }

    const response = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "x-api-key": API_KEY,
        "anthropic-version": "2023-06-01",
        "content-type": "application/json",
      },
      body: JSON.stringify({
        model: "claude-haiku-4-5-20251001",
        max_tokens: 1024,
        system: sysPrompt,
        messages: [{ role: "user", content: prompt }],
      }),
    });

    const data = await response.json();
    const result = data.content?.[0]?.text || "";

    return {
      statusCode: 200,
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*",
      },
      body: JSON.stringify({ result }),
    };
  } catch (err) {
    return {
      statusCode: 500,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ error: err.message }),
    };
  }
};
